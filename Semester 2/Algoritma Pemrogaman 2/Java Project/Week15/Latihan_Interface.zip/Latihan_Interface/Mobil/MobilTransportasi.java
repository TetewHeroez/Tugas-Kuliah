package Aplro2.Week15.Latihan_Interface.Mobil;

public abstract class MobilTransportasi extends Mobil{
    protected int jmlKursi;
    public abstract void TambahPenumpang();
}
