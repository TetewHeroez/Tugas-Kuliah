package Aplro2.Week15.Latihan_Interface.Mobil;

public abstract class Mobil implements interfaceMobil{
    protected boolean mesin = false;
}
