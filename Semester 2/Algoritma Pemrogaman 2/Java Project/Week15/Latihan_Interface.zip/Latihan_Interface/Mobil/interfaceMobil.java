package Aplro2.Week15.Latihan_Interface.Mobil;

public interface interfaceMobil {
    public void NyalakanMesin();
    public void MatikanMesin();
    public void TambahkanGigi();
    public void TurunkanGigi();
    public void Gas();
    public void Rem();
}
