package Aplro2.Week15.Latihan_Interface.Mobil;

public abstract class MobilNegara extends Mobil implements interfaceSirine{
       public abstract void NyalakanTape();
       public abstract void NyalakanTV();
       public abstract void NyalakanAC();
}
