package Aplro2.Week15.Latihan_Interface.Mobil;

public interface interfaceSirine {
    public void NyalakanSirine();
    public void MatikanSirine();
    public void GantiSuaraSirine(int jenis);
}
