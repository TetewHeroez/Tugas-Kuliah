package Aplro2.Week15.Latihan_Interface.TV;

public interface interfaceChannelRadio {
    public void gantiChannel(int c);
}
