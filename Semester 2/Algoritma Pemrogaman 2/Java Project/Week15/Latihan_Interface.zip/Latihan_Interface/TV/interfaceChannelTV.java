package Aplro2.Week15.Latihan_Interface.TV;

public interface interfaceChannelTV {
    public void PindahChannel(int c);
}
