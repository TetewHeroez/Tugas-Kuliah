package Aplro2.Week15.Latihan_Interface.TV;

public interface InterfaceElektronik {
    public void On();
    public void Off();
}
